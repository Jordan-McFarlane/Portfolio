package Text_Editor;

import javax.swing.*;
import java.awt.*;


public class TextPanel extends JPanel {

    private JTextArea textArea;
    private String string;

    public TextPanel(){


        textArea = new JTextArea();
        //textArea.setText(string);
       // textArea.write(string);
        setLayout(new BorderLayout());

        add(new JScrollPane(textArea),BorderLayout.CENTER);






    }

    public void setTextArea(String string)
    {

        textArea.setText(string);


    }









}
