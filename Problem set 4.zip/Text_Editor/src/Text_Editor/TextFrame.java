package Text_Editor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import java.io.*;
import javax.swing.border.EmptyBorder;
import javax.swing.JFileChooser;



public class TextFrame extends JFrame implements ActionListener{

    private TextPanel textPanel;
    //private JButt



    private TextFrame() throws HeadlessException {
        //Sets the title
        setTitle("Notepad");
        //Used to organize the page
        setLayout(new BorderLayout());

        //Add text area class
        textPanel = new TextPanel();



        //Set size and make the(x) bar terminate program
        setSize(900, 600);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //Adding stuff
        add(textPanel, BorderLayout.CENTER);



        //  Add Java Menus
        JMenuBar jMenuBar = new JMenuBar();
        setJMenuBar(jMenuBar);


        //
        //  Add menu to Jmenu
        JMenu menu = new JMenu();
        menu.setText("File");
        jMenuBar.add(menu);

        //  Add New Item menu
        JMenuItem New = new JMenuItem();
        New.setText("New");
        New.addActionListener(this);
        menu.add(New);
        //  Add Open Item Menu
        JMenuItem Open = new JMenuItem();
        Open.setText("Open");
        Open.addActionListener(this);
        menu.add(Open);
        //  Add Save Item menu
        JMenuItem Save = new JMenuItem();
        Save.setText("Save");
        Save.addActionListener(this);
        menu.add(Save);
        //  Add Exit Item menu
        JMenuItem Exit = new JMenuItem();
        Exit.setText("Exit");
        Exit.addActionListener(this);
        menu.add(Exit);





    }




    public static void main(String[] args) {

       //Test Frame class is declared
        TextFrame text = new TextFrame();
       //Makes the Frame Visible
        text.setVisible(true);

    }



//Performs Actions
    public void actionPerformed(ActionEvent e) {


        switch (e.getActionCommand().toUpperCase()) {
            case "NEW":

      textPanel.setTextArea("");
                break;
            case "OPEN":
JFileChooser fileChooser1 = new JFileChooser();
///int returnVal = fileChooser1.showOpenDialog(getParent())
if(fileChooser1.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
{

    File file = fileChooser1.getSelectedFile();
    System.out.println("Heres your File Bro");

}


                break;
            case "SAVE":



JFileChooser fileChooser2 = new JFileChooser();

if(fileChooser2.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
{

    File file = fileChooser2.getSelectedFile();
    System.out.println("Your Files saved Bro");


}



                break;
            case "EXIT":

            int dialogButton = JOptionPane.YES_NO_OPTION;

            JOptionPane.showConfirmDialog(null,"Do you wanna save first? ","Warning",dialogButton);

            if(dialogButton ==JOptionPane.YES_NO_OPTION)
            {
                System.exit(NORMAL);

            }
                break;

        }


    }





}



