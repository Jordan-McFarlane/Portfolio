package Calculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Calculator extends JFrame  {


    private JTextField screen;
    private JButton zero, one, two, three, four, five, six, seven, eight, nine, plus, minus, mult, div, sqrt, CE, C, frac, mod, backspace, decimal, neg, equals;
    private JPanel form;
    private String  runner;
    private String gunner;
    private String solString;
    private double solDouble;
    private boolean clickedEquals = false;
    private boolean Operation = false;
    private char conv = ' ';

    public Calculator() throws HeadlessException {


        //Sets Title and length
        setTitle("Java Swing Calculator");
        setSize(680, 500);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


        setLayout(new BorderLayout());

        getContentPane().setBackground(Color.WHITE);


        //File Help Toolbar
        JMenuBar jMenuBar = new JMenuBar();
        setJMenuBar(jMenuBar);

        //  Add menu to Jmenu
        JMenu file = new JMenu();
        file.setText("File");
        jMenuBar.add(file);

        JMenu help = new JMenu();
        help.setText("Help");
        jMenuBar.add(help);


        //Screen
        screen = new JTextField(null, 50);
        screen.setEditable(false);


//Buttons
        zero = new JButton("0");
        one = new JButton("1");
        two = new JButton("2");
        three = new JButton("3");
        four = new JButton("4");
        five = new JButton("5");
        six = new JButton("6");
        seven = new JButton("7");
        eight = new JButton("8");
        nine = new JButton("9");
        plus = new JButton("+");
        minus = new JButton("-");
        mult = new JButton("*");
        div = new JButton("/");
        sqrt = new JButton("sqrt");
        CE = new JButton("CE");
        C = new JButton("C");
        frac = new JButton("1/x");
        mod = new JButton("%");
        backspace = new JButton("backspace");
        decimal = new JButton(".");
        neg = new JButton("+/-");
        equals = new JButton("=");


        Dimension dim2 = new Dimension(300, 35);
        Dimension dim1 = new Dimension(100, 35);
        Dimension dim3 = new Dimension(50, 35);
        screen.setPreferredSize(dim3);
        backspace.setPreferredSize(dim2);
        one.setPreferredSize(dim1);
        two.setPreferredSize(dim1);
        three.setPreferredSize(dim1);
        four.setPreferredSize(dim1);
        five.setPreferredSize(dim1);
        six.setPreferredSize(dim1);
        seven.setPreferredSize(dim1);
        eight.setPreferredSize(dim1);
        nine.setPreferredSize(dim1);
        zero.setPreferredSize(dim1);
        plus.setPreferredSize(dim1);
        minus.setPreferredSize(dim1);
        mult.setPreferredSize(dim1);
        div.setPreferredSize(dim1);
        sqrt.setPreferredSize(dim1);
        CE.setPreferredSize(dim1);
        C.setPreferredSize(dim1);
        frac.setPreferredSize(dim1);
        mod.setPreferredSize(dim1);
        backspace.setPreferredSize(dim1);
        decimal.setPreferredSize(dim1);
        neg.setPreferredSize(dim1);
        equals.setPreferredSize(dim1);







        Digits dig = new Digits();
        Calculations calcu = new Calculations();








        one.addActionListener(dig);
        two.addActionListener(dig);
        three.addActionListener(dig);
        four.addActionListener(dig);
        five.addActionListener(dig);
        six.addActionListener(dig);
        seven.addActionListener(dig);
        eight.addActionListener(dig);
        nine.addActionListener(dig);
        zero.addActionListener(dig);
        decimal.addActionListener(dig);
        neg.addActionListener(dig);
        backspace.addActionListener(dig);








        plus.addActionListener(calcu);
        mult.addActionListener(calcu);
        div.addActionListener(calcu);
        mod.addActionListener(calcu);
        equals.addActionListener(calcu);
        minus.addActionListener(calcu);
        C.addActionListener(calcu);
        CE.addActionListener(calcu);















        form = new JPanel();
        form.setLayout(new FlowLayout());
        form.setBackground(Color.blue);



        form.add(screen, BorderLayout.NORTH);

        form.add(backspace);
        form.add(CE);
        form.add(C);
        form.add(seven);
        form.add(eight);
        form.add(nine);
        form.add(div);
        form.add(sqrt);
        form.add(four);
        form.add(five);
        form.add(six);
        form.add(mult);
        form.add(frac);
        form.add(one);
        form.add(two);
        form.add(three);
        form.add(minus);
        form.add(mod);
        form.add(zero);
        form.add(neg);
        form.add(decimal);
        form.add(plus);
        form.add(equals);

        this.setContentPane(form);


    }


    public static void main(String[] args) {


        //Test Frame class is declared
        Calculator calc = new Calculator();
        //Makes the Frame Visible
        calc.setVisible(true);


    }


    //Performs Actions
    private class Digits implements ActionListener {
        public void actionPerformed(ActionEvent e) {


            switch (e.getActionCommand().toUpperCase()) {
                case "1":

                    if (!Operation) {
                        if (runner == null) {
                            runner = "1";
                        } else {
                            runner += "1";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = "1";
                        } else {
                            gunner += "1";
                        }

                    }


                    break;

                case "2":


                    if (!Operation) {
                        if (runner == null) {
                            runner = "2";
                        } else {
                            runner += "2";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = "2";
                        } else {
                            gunner += "2";
                        }

                    }


                    break;

                case "3":


                    if (!Operation) {
                        if (runner == null) {
                            runner = "3";
                        } else {
                            runner += "3";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = "3";
                        } else {
                            gunner += "3";
                        }

                    }


                    break;

                case "4":


                    if (!Operation) {
                        if (runner == null) {
                            runner = "4";
                        } else {
                            runner += "4";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = "4";
                        } else {
                            gunner += "4";
                        }

                    }

                    break;

                case "5":


                    if (!Operation) {
                        if (runner == null) {
                            runner = "5";
                        } else {
                            runner += "5";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = "5";
                        } else {
                            gunner += "5";
                        }

                    }

                    break;

                case "6":


                    if (!Operation) {
                        if (runner == null) {
                            runner = "6";
                        } else {
                            runner += "6";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = "6";
                        } else {
                            gunner += "6";
                        }

                    }

                    break;

                case "7":


                    if (!Operation) {
                        if (runner == null) {
                            runner = "7";
                        } else {
                            runner += "7";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = "7";
                        } else {
                            gunner += "7";
                        }

                    }


                    break;

                case "8":


                    if (!Operation) {
                        if (runner == null) {
                            runner = "8";
                        } else {
                            runner += "8";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = "8";
                        } else {
                            gunner += "8";
                        }

                    }

                    break;


                case "9":


                    if (!Operation) {
                        if (runner == null) {
                            runner = "9";
                        } else {
                            runner += "9";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = "9";
                        } else {
                            gunner += "9";
                        }

                    }


                    break;
                case "0":


                    if (!Operation) {
                        if (runner == null) {
                            runner = "0";
                        } else {
                            runner += "0";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = "0";
                        } else {
                            gunner += "0";
                        }

                    }

                    break;

                case ".":


                    if (!Operation) {
                        if (runner == null) {
                            runner = ".";
                        } else if (runner.equals(".")) {


                        } else if (runner.length() >= 2) {


                        } else {
                            runner += ".";
                        }

                    } else {
                        if (gunner == null) {
                            gunner = ".";
                        } else if (gunner.equals(".")) {
                            int a;
                        } else if (gunner.length() >= 2) {


                        } else {
                            gunner += ".";
                        }

                    }

                    break;


                case "+/-":


                    if (!Operation) {
                        if (runner == null) {
                            runner = "-";
                        } else if (runner != null && runner.startsWith("-")) {
                            runner = runner.substring(1);
                        } else {

                            runner = "-" + runner;
                        }

                    } else {


                        if (gunner == null) {
                            gunner = "-";
                        } else if (gunner != null && gunner.startsWith("-")) {
                            gunner = gunner.substring(1);
                        } else {

                            gunner = "-" + gunner;
                        }


                    }


                    break;

                case "backspace":
                    if (!Operation)
                    {
                        if (runner != null && runner.length() > 0) {

                            runner = runner.substring(0, runner.length() - 1);


                        }
                        else if(gunner != null && gunner.length() > 0)
                        {
                            gunner = gunner.substring(0, gunner.length() - 1);


                        }






                    }

                    break;





            }

            if (!clickedEquals && !Operation) {



                screen.setText(runner);
            }
            else {
                screen.setText(gunner);
            }

        }
    }


    private class Calculations implements ActionListener {
        public void actionPerformed(ActionEvent e) {





            switch (e.getActionCommand().toUpperCase()) {

                case "+":

                    if (runner != null && gunner == null) {
                        Operation = true;
                        conv = '+';

                    }

                    break;

                case "-":

                    if (runner != null && gunner == null) {
                        Operation = true;
                        conv = '-';

                    }

                    break;

                case "*":

                    if (runner != null && gunner == null) {
                        Operation = true;
                        conv = '*';

                    }

                    break;

                case "/":

                    if (runner != null && gunner == null) {
                        Operation = true;
                        conv = '/';

                    }

                    break;

                case "%":


                    if (runner != null && gunner == null) {
                        Operation = true;
                        conv = '%';

                    }
                    break;


                case "=":


                    double num1;
                    double num2;

                    num1 = Double.parseDouble(runner);
                    num2 = Double.parseDouble(gunner);


                    if (runner != null && gunner != null) {


                        switch (conv) {
                            case '+':



                                solDouble = num1 + num2;

                                break;

                            case '-':



                                solDouble = num1 - num2;


                                break;

                            case '*':



                                solDouble = num1 * num2;


                                break;

                            case '/':


                                solDouble = num1 / num2;


                                break;

                            case '%':


                                solDouble = num1 % num2;

                                break;

                        }


                        solString = Double.toString(solDouble);
                        screen.setText(solString);

                    }
                    break;

                case "C":

                    runner = null;
                    gunner = null;
                    clickedEquals = false;
                    Operation = false;
                    conv = ' ';
                    screen.setText(null);
                    break;

                case "CE":


                    gunner = null;
                    clickedEquals = false;
                    Operation = false;
                    conv = ' ';
                    screen.setText(null);
                    break;







            }


        }


    }


}





