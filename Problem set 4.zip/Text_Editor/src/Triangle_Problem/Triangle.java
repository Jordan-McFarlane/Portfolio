package Triangle_Problem;

import javax.swing.*;
import java.awt.*;

public class Triangle extends JPanel
{

private int Lvl;

private Triangle(int Lvl)
{
    this.Lvl = Lvl;

}

public void paint(Graphics g) {

    super.paint(g);
    Point top = new Point(150, 30);
    Point right = new Point(300, 500);
    Point left = new Point(20, 500);


    drawTriangle(g, Lvl, top, left, right);


}



private static Point midPoint(Point point1,Point point2) {

    return new Point((point1.x + point2.x)/2,(point1.y + point2.y)/2);


}





private static void drawTriangle(Graphics g, int Lvl,Point top,Point left, Point right) {

    if (Lvl < 0) {
        return;
    }

    g.setColor(Color.blue);

    Polygon poly = new Polygon();

    poly.addPoint(left.x, left.y);
    poly.addPoint(right.x, right.y);
    poly.addPoint(top.x, top.y);

    g.drawPolygon(poly);

    Point point31 = midPoint(right, top);
    Point point12 = midPoint(top, left);
    Point point23 = midPoint(left, right);


    drawTriangle(g, Lvl - 1, top, point12, point31);
    drawTriangle(g, Lvl - 1, point12, point31, right);
    drawTriangle(g, Lvl - 1, point12, left, point23);

}













    public static void main(String[] args)
    {
        JFrame frame = new JFrame("SierpinskiTriangle.class");
        Triangle panel = new Triangle(3);
        frame.add(panel);
        frame.setSize(700,600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setVisible(true);



    }




}
