package Bar_Chart_Problem;

import javax.swing.*;
import java.awt.*;
import java.awt.Dimension;

public class BarChart extends JPanel {

    private double[] value;
    private String[] label;
    private String Topic;
    private Color[] colors;

    private BarChart(double[] value, String[] label, String Topic,Color[] colors) throws HeadlessException
    {
        this.value = value;
        this.label = label;
        this.Topic = Topic;
        this.colors = colors;

    }

    public void paint(Graphics g)
    {

        super.paint(g);

        double minVal = 0.0;
        double maxVal = 0.0;


        if(value == null || value.length == 0)
        {
            return;
        }




        for(int i = 0; i < value.length; i++)
        {


            if(minVal > value[i])
            {
                minVal = value[i];

            }

            if(maxVal < value[i])
            {

                maxVal = value[i];
            }


        }


        Dimension d = getSize();
        int inputWidth = d.width;
        int inputHeight = d.height;
        int barWidth = inputWidth / value.length;


        //set Fonts
        Font LabelFont = new Font("Times New Roman", Font.BOLD,25);
        FontMetrics LabelFontMetrics = g.getFontMetrics(LabelFont);
        Font TopicFont = new Font("Times New Roman", Font.BOLD,25);
        FontMetrics TopicFontMetrics = g.getFontMetrics(TopicFont);

        int TopicWidth = TopicFontMetrics.stringWidth(Topic);
        int strgHeigth = TopicFontMetrics.getAscent();
        int strgWidth = (inputWidth - TopicWidth)/2;



        g.setFont(TopicFont);
        g.drawString(Topic, strgWidth, strgHeigth);

        int ceiling = TopicFontMetrics.getHeight();
        int floor = LabelFontMetrics.getHeight();


        if(maxVal == minVal)
        {
            return;
        }

        double scale = (inputHeight - ceiling - floor)/(maxVal - minVal);


        strgHeigth = inputHeight - LabelFontMetrics.getDescent();
        g.setFont(LabelFont);


        for(int j = 0; j < value.length; j++) {

            int value_1 = j * barWidth + 1;
            int value_2 = ceiling;
            int heigth = (int) ((value[j]) * scale);

            if (value[j] >= 0) {
                value_2 += (int) ((maxVal - value[j] * scale));


            } else {


                value_2 += (int) ((maxVal * scale));
                heigth = -heigth;


            }


            g.setColor(colors[j]);
            g.fillRect(value_1, value_2 - 25,barWidth - 65, heigth);
            g.setColor(Color.black);
            g.drawRect(value_1, value_2 - 25, barWidth - 65, heigth);

            int LabelWidth = LabelFontMetrics.stringWidth(label[j]);
            strgWidth = j*barWidth + (barWidth - LabelWidth)/2;

            g.drawString(label[j],strgWidth, strgHeigth);


        }

    }






    public static void main(String[] args)
    {
        JFrame frame = new JFrame();
        frame.setSize(600,500);
        // frame.setDefaultLookAndFeelDecorated(true);
        String Topic = "Graph";

        double[] value = new double[] {700,600,500,150};

        String[] label = new String[]{"China","India","USA","Australia"};

        Color[] colors = new Color[]
                {
                        Color.red,
                        Color.yellow,
                        Color.blue,
                        Color.green



                };


        BarChart barChart = new BarChart(value,label,Topic,colors);
        frame.add(barChart);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);







    }
}
